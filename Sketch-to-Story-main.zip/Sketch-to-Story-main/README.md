# ✏️ Sketch to Story

A Generative AI web app that turns your doodles into short stories — built with **Google Gemini** and **Streamlit**.

## What it does
Draw a sketch directly in the browser (or upload one), pick a genre and length, and Gemini's multimodal model interprets the shapes and writes a creative short story inspired by it.

## Features
- 🎨 In-browser drawing canvas — no need to upload files
- 📤 Or upload an existing sketch/image
- 🎭 Choose genre: Fantasy, Sci-fi, Mystery, Comedy, Horror, Fairy tale, Slice of life
- 📏 Adjustable story length
- 💾 Download the generated story as a .txt file

## Tech stack
- **Streamlit** — web app framework and UI
- **Google Gemini API** (`google-genai` SDK) — multimodal AI model that reads the sketch and writes the story
- **streamlit-drawable-canvas** — in-browser drawing widget
- **Pillow (PIL)** — image processing
- **python-dotenv** — environment variable / API key management

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     Frontend (Browser)                    │
│  ┌────────────────┐        ┌──────────────────────────┐  │
│  │ Drawing Canvas  │  OR    │  File Uploader            │  │
│  │ (streamlit-     │        │  (sketch/image upload)    │  │
│  │ drawable-canvas)│        │                            │  │
│  └────────┬────────┘        └───────────┬────────────────┘  │
│           └────────────┬─────────────────┘                  │
│                         │                                    │
│            ┌────────────▼─────────────┐                      │
│            │  Genre + Length selectors │                      │
│            └────────────┬─────────────┘                      │
└─────────────────────────┼──────────────────────────────────┘
                           │
                 ┌─────────▼──────────┐
                 │   Streamlit Server   │
                 │   (Python backend)   │
                 └─────────┬──────────┘
                           │
           1. Convert canvas/upload → PNG bytes
           2. Build prompt (genre, length, instructions)
           3. Package image + prompt into API request
                           │
                 ┌─────────▼──────────┐
                 │   Google Gemini API  │
                 │  (google-genai SDK)  │
                 │  Multimodal model:   │
                 │  gemini-flash-latest │
                 └─────────┬──────────┘
                           │
           Gemini analyzes image content (shapes,
           objects, characters) + generates story text
                           │
                 ┌─────────▼──────────┐
                 │   Streamlit Server    │
                 │  Renders response      │
                 └─────────┬──────────┘
                           │
                 ┌─────────▼──────────┐
                 │      Browser           │
                 │  • Story displayed     │
                 │  • Download as .txt    │
                 └─────────────────────────┘
```

### Data flow
1. **Input capture** — user draws on an HTML5 canvas (via `streamlit-drawable-canvas`) or uploads an image file
2. **Preprocessing** — the app converts the canvas pixel array or uploaded file into a PIL `Image`, then serializes it to PNG bytes in memory (no files written to disk)
3. **Prompt construction** — genre and length selections are interpolated into a text prompt instructing Gemini how to interpret and write from the sketch
4. **API call** — the image bytes (as a `Part`) and the text prompt are sent together in a single multimodal request to the Gemini API via `client.models.generate_content()`
5. **Inference** — Gemini's multimodal model processes the image and text jointly and returns a generated story as plain text
6. **Rendering** — Streamlit displays the response; a download button lets the user save the story locally

### Key design choices
- **Stateless per request** — no database or persistent storage; each generation is a fresh API call, keeping the app simple to deploy
- **In-memory image handling** — images are never saved to disk, only held as bytes during the request lifecycle
- **Single multimodal call** — no separate image-captioning step; Gemini handles vision + language generation in one pass, reducing latency and complexity

## Setup

```bash
pip install -r requirements.txt
```

Add your Gemini API key (get one free at [Google AI Studio](https://aistudio.google.com/apikey)) to a `.env` file:
```
GEMINI_API_KEY=your_key_here
```

Run:
```bash
streamlit run sketch_to_story.py
```

## Possible extensions
- Multi-turn "continue the story" using `client.chats.create()`
- Generate an illustration of a key scene alongside the text
- Session history of past sketches and stories via `st.session_state`
- Deploy for free on [Streamlit Community Cloud](https://streamlit.io/cloud)
