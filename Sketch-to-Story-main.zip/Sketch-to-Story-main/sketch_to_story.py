"""
Sketch-to-Story
----------------
Draw a doodle (or upload a sketch/image), pick a genre and tone,
and Gemini writes a short story inspired by what it sees.

Run with: streamlit run sketch_to_story.py
"""

import io
import os

import streamlit as st
from dotenv import load_dotenv
from PIL import Image
from streamlit_drawable_canvas import st_canvas
from google import genai
from google.genai import types

load_dotenv()

st.set_page_config(page_title="Sketch to Story", page_icon="✏️", layout="centered")

# ---------- Gemini client ----------
API_KEY = os.environ.get("GEMINI_API_KEY")
if not API_KEY:
    st.error("No GEMINI_API_KEY found. Add it to a .env file in this folder.")
    st.stop()

client = genai.Client(api_key=API_KEY)
MODEL = "gemini-flash-latest"

# ---------- UI ----------
st.title("✏️ Sketch to Story")
st.caption("Draw something (or upload a sketch) and get a short story inspired by it.")

tab_draw, tab_upload = st.tabs(["Draw", "Upload an image"])

image_to_send = None

with tab_draw:
    st.write("Sketch anything below — shapes, doodles, stick figures, whatever.")
    canvas_result = st_canvas(
        fill_color="rgba(255, 255, 255, 0)",
        stroke_width=4,
        stroke_color="#000000",
        background_color="#FFFFFF",
        height=400,
        width=500,
        drawing_mode="freedraw",
        key="canvas",
    )
    if canvas_result.image_data is not None:
        # Only treat it as a real sketch if something was actually drawn
        img_array = canvas_result.image_data
        if img_array[:, :, :3].min() < 255:  # not a blank white canvas
            image_to_send = Image.fromarray(img_array.astype("uint8"), "RGBA").convert("RGB")

with tab_upload:
    uploaded = st.file_uploader("Upload a sketch or drawing", type=["png", "jpg", "jpeg"])
    if uploaded is not None:
        image_to_send = Image.open(uploaded).convert("RGB")
        st.image(image_to_send, caption="Your uploaded sketch", use_container_width=True)

st.divider()

col1, col2 = st.columns(2)
with col1:
    genre = st.selectbox(
        "Genre",
        ["Fantasy", "Sci-fi", "Mystery", "Comedy", "Horror", "Fairy tale", "Slice of life"],
    )
with col2:
    length = st.selectbox("Length", ["Very short (~100 words)", "Short (~250 words)", "Medium (~500 words)"])

generate = st.button("Generate story", type="primary", disabled=image_to_send is None)

if image_to_send is None:
    st.info("Draw something or upload an image to enable story generation.")

if generate and image_to_send is not None:
    buf = io.BytesIO()
    image_to_send.save(buf, format="PNG")
    img_bytes = buf.getvalue()

    prompt = (
        f"Look at this sketch/drawing. Write a {genre.lower()} short story "
        f"(around {length.split('(')[1].rstrip(')')}) inspired by the shapes, "
        f"objects, or characters you can identify in it. Be creative and playful — "
        f"treat vague shapes as intentional story elements rather than pointing out "
        f"that it's a rough sketch. Give the story a title."
    )

    with st.spinner("Writing your story..."):
        response = client.models.generate_content(
            model=MODEL,
            contents=[
                types.Part.from_bytes(data=img_bytes, mime_type="image/png"),
                prompt,
            ],
        )

    st.subheader("Your story")
    st.write(response.text)
    st.download_button("Download story as .txt", response.text, file_name="story.txt")
